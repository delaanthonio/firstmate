#!/usr/bin/env bash
set -euo pipefail
ROOT=$PWD
LAB=$(mktemp -d "$TMPDIR/droid-public-trust.XXXXXX")
SOCKET="fm-droid-retire-$$"
cleanup() { tmux -L "$SOCKET" kill-server >/dev/null 2>&1 || true; rm -rf "$LAB"; }
trap cleanup EXIT
unset FM_ROOT_OVERRIDE FM_STATE_OVERRIDE FM_DATA_OVERRIDE FM_CONFIG_OVERRIDE FM_PROJECTS_OVERRIDE FM_GATE_REFUSE_BYPASS TASKS_AXI_FILE TASKS_AXI_BACKEND
export HOME="$LAB/user" FM_HOME="$LAB/fleet" TREEHOUSE_ROOT="$LAB/pool"
mkdir -p "$HOME/.factory"
bin/fm-lab-home.sh create "$FM_HOME"
printf 'manual\n' > "$FM_HOME/config/backlog-backend"
printf 'tmux\n' > "$FM_HOME/config/backend"
store="$HOME/.factory/settings.json"
printf '%s\n' '{"otherSetting":"preserve","trustedFolders":{"/unrelated":{"trustedAt":"existing"}}}' > "$store"
git init -q -b main "$LAB/project"
git -C "$LAB/project" -c user.name=guard -c user.email=guard@local commit -q --allow-empty -m init
mkdir -p "$LAB/pool/.treehouse/project-test/1"
wt="$LAB/pool/.treehouse/project-test/1/project"
git -C "$LAB/project" worktree add -q --detach "$wt"
ln -s "$wt" "$LAB/alias"
trust() { "$ROOT/bin/fm-droid-trust.sh" "$@"; }
trust --receipt "$FM_HOME/state/owner.droid-trust" "$LAB/alias" "$LAB/project"
cp "$store" "$LAB/original"
for bad in "$LAB/project" "$LAB" "$HOME"; do
  if trust "$bad" "$LAB/project"; then exit 1; fi
done
cmp "$store" "$LAB/original"
printf 'EXACT_SCOPE_STATE\n'; cat "$store"
trust --rollback "$FM_HOME/state/owner.droid-trust"
jq -e '.otherSetting == "preserve" and .trustedFolders == {"/unrelated":{"trustedAt":"existing"}}' "$store"
trust "$LAB/alias" "$LAB/project"
cp "$store" "$LAB/original"
trust --receipt "$FM_HOME/state/owner.droid-trust" "$LAB/alias" "$LAB/project"
trust --rollback "$FM_HOME/state/owner.droid-trust"
cmp "$store" "$LAB/original"
printf 'PREEXISTING_ROLLBACK_STATE\n'; cat "$store"
trust --remove "$LAB/alias" "$LAB/project"
mkdir -p "$LAB/alias-user/.factory"
ln -s "$store" "$LAB/alias-user/.factory/settings.json"
for i in 1 2 3 4; do git -C "$LAB/project" worktree add -q --detach "$LAB/concurrent-$i"; done
for round in 1 2 3; do
  pids=()
  for i in 1 2 3 4; do
    user="$HOME"; [ "$((i % 2))" -eq 0 ] || user="$LAB/alias-user"
    HOME="$user" trust "$LAB/concurrent-$i" "$LAB/project" & pids+=("$!")
  done
  for pid in "${pids[@]}"; do wait "$pid"; done
  jq -e '.trustedFolders | length == 5' "$store"
  pids=()
  for i in 1 2 3 4; do
    user="$HOME"; [ "$((i % 2))" -eq 0 ] || user="$LAB/alias-user"
    HOME="$user" trust --remove "$LAB/concurrent-$i" "$LAB/project" & pids+=("$!")
  done
  for pid in "${pids[@]}"; do wait "$pid"; done
  jq -e '.otherSetting == "preserve" and .trustedFolders == {"/unrelated":{"trustedAt":"existing"}}' "$store"
done
[ -L "$LAB/alias-user/.factory/settings.json" ]
printf 'CONCURRENT_FINAL_STATE\n'; cat "$store"
# Retired task records, including a non-Droid pooled successor, are disposable
# data for the real lifecycle CLI. There is no substituted backend or harness.
tmux -L "$SOCKET" new-session -d -s firstmate -x 140 -y 45 -c "$LAB/project" 'bash --noprofile --norc'
export TMUX
TMUX=$(tmux -L "$SOCKET" display-message -p -t firstmate '#{socket_path},#{pid},0')
write_record() {
  local id=$1 harness=$2
  printf 'window=firstmate:fm-%s\nendpoint_task_id=%s\nworktree=%s\nproject=%s\nkind=scout\nharness=%s\n' "$id" "$id" "$wt" "$LAB/project" "$harness" > "$FM_HOME/state/$id.meta"
  mkdir -p "$FM_HOME/data/$id"
  printf 'Disposable trust verification completed.\n' > "$FM_HOME/data/$id/report.md"
  "$ROOT/bin/fm-captain-hold.sh" complete "$id" --none
}
write_record owner droid
write_record successor claude
trust --receipt "$FM_HOME/state/owner.droid-trust" "$LAB/alias" "$LAB/project"
git -C "$LAB/project" worktree remove "$wt"
rm "$LAB/alias"
"$ROOT/bin/fm-teardown.sh" owner
[ ! -e "$FM_HOME/state/owner.meta" ]
[ -e "$FM_HOME/state/successor.droid-trust" ]
printf 'TRANSFERRED_RECEIPT\n'; cat "$FM_HOME/state/successor.droid-trust"
"$ROOT/bin/fm-teardown.sh" successor
[ ! -e "$FM_HOME/state/successor.meta" ]
[ ! -e "$FM_HOME/state/successor.droid-trust" ]
jq -e '.otherSetting == "preserve" and .trustedFolders == {"/unrelated":{"trustedAt":"existing"}}' "$store"
printf 'SUCCESSOR_FINAL_STATE\n'; cat "$store"
# Re-running a receipt-free cleanup never recreates trust.
write_record retired droid
"$ROOT/bin/fm-teardown.sh" retired
jq -e '.trustedFolders == {"/unrelated":{"trustedAt":"existing"}}' "$store"
printf 'RECEIPT_FREE_FINAL_STATE\n'; cat "$store"
# Force the reachable race at the real CLI's successor metadata retirement.
git -C "$LAB/project" worktree add -q --detach "$wt"
ln -s "$wt" "$LAB/alias"
write_record owner droid
write_record successor claude
trust --receipt "$FM_HOME/state/owner.droid-trust" "$LAB/alias" "$LAB/project"
git -C "$LAB/project" worktree remove "$wt"
rm "$LAB/alias"
mkdir -p "$LAB/faultbin"
cat > "$LAB/faultbin/rm" <<'WRAP'
#!/usr/bin/env bash
for arg in "$@"; do
  if [ "$arg" = "$FM_RACE_STATE/successor.turn-ended" ]; then
    touch "$FM_RACE_READY"
    for ((i=0; i<6000; i++)); do
      [ ! -e "$FM_RACE_RELEASE" ] || break
      sleep 0.01
    done
    [ -e "$FM_RACE_RELEASE" ] || exit 1
  fi
done
exec /bin/rm "$@"
WRAP
chmod +x "$LAB/faultbin/rm"
PATH="$LAB/faultbin:$PATH" FM_RACE_STATE="$FM_HOME/state" FM_RACE_READY="$LAB/ready" FM_RACE_RELEASE="$LAB/release" \
  "$ROOT/bin/fm-teardown.sh" successor > "$LAB/successor.log" 2>&1 &
successor_pid=$!
for ((i=0;i<1000;i++)); do [ ! -e "$LAB/ready" ] || break; sleep 0.01; done
if [ ! -e "$LAB/ready" ]; then touch "$LAB/release"; wait "$successor_pid" || true; cat "$LAB/successor.log"; exit 1; fi
rc=0
"$ROOT/bin/fm-teardown.sh" owner || rc=$?
[ "$rc" -ne 0 ]
[ -e "$FM_HOME/state/owner.meta" ]
[ -e "$FM_HOME/state/owner.droid-trust" ]
[ ! -e "$FM_HOME/state/successor.droid-trust" ]
printf 'CONTENTION_STATE owner_record=retained owner_receipt=retained successor_receipt=absent owner_exit=%s\n' "$rc"
touch "$LAB/release"
wait "$successor_pid"
cat "$LAB/successor.log"
[ ! -e "$FM_HOME/state/successor.meta" ]
"$ROOT/bin/fm-teardown.sh" owner
[ ! -e "$FM_HOME/state/owner.meta" ]
[ ! -e "$FM_HOME/state/owner.droid-trust" ]
[ ! -e "$FM_HOME/state/successor.droid-trust" ]
jq -e '.otherSetting == "preserve" and .trustedFolders == {"/unrelated":{"trustedAt":"existing"}}' "$store"
printf 'CONCURRENT_RETIREMENT_FINAL_STATE no_metadata=true no_orphan_receipts=true\n'; cat "$store"
