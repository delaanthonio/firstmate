#!/usr/bin/env bash
set -euo pipefail
ROOT=$PWD
LAB=$(mktemp -d "$TMPDIR/droid-boundaries.XXXXXX")
trap 'chmod -R u+w "$LAB"; rm -rf "$LAB"' EXIT
unset FM_ROOT_OVERRIDE FM_STATE_OVERRIDE FM_DATA_OVERRIDE FM_CONFIG_OVERRIDE FM_PROJECTS_OVERRIDE TASKS_AXI_FILE TASKS_AXI_BACKEND FM_GATE_REFUSE_BYPASS
export HOME="$LAB/user" FM_HOME="$LAB/fleet"
mkdir -p "$HOME"
bin/fm-lab-home.sh create "$FM_HOME"
printf 'tmux\n' > "$FM_HOME/config/backend"
printf 'manual\n' > "$FM_HOME/config/backlog-backend"
cat > "$LAB/no-jq.bash" <<'ENV'
command() {
  if [ "${1:-}" = -v ] && [ "${2:-}" = jq ]; then return 1; fi
  builtin command "$@"
}
jq() { return 127; }
ENV
bootstrap() { BASH_ENV="$LAB/no-jq.bash" FM_BOOTSTRAP_DETECT_ONLY=1 FM_BOOTSTRAP_NETWORK=skip "$ROOT/bin/fm-bootstrap.sh"; }
printf 'claude\n' > "$FM_HOME/config/crew-harness"
bootstrap > "$LAB/non-droid.log"
if grep -q 'MISSING: jq' "$LAB/non-droid.log"; then cat "$LAB/non-droid.log"; exit 1; fi
printf 'NON_DROID_BOOTSTRAP no-jq-diagnostic=true\n'
printf 'droid\n' > "$FM_HOME/config/crew-harness"
bootstrap > "$LAB/droid.log"
grep 'MISSING: jq' "$LAB/droid.log"
printf 'claude\n' > "$FM_HOME/config/crew-harness"
printf '%s\n' '{"rules":[{"when":"Droid work","use":{"harness":"droid","model":"custom:GPT-5.6-Sol-0","effort":"dynamic"}}]}' > "$FM_HOME/config/crew-dispatch.json"
bootstrap > "$LAB/profile.log"
grep -E 'jq|CREW_DISPATCH' "$LAB/profile.log"
# Existing real jq consumes the dispatch profile; the model id and dynamic effort
# are accepted without executing a harness.
FM_BOOTSTRAP_DETECT_ONLY=1 FM_BOOTSTRAP_NETWORK=skip "$ROOT/bin/fm-bootstrap.sh" > "$LAB/valid-profile.log"
if grep -q '^CREW_DISPATCH: invalid' "$LAB/valid-profile.log"; then cat "$LAB/valid-profile.log"; exit 1; fi
printf 'DROID_PROFILE_BOOTSTRAP literal-custom-id=accepted dynamic=accepted\n'
# Reach the task-kind boundary before settings or endpoints are allocated.
mkdir -p "$LAB/mate"
rc=0
"$ROOT/bin/fm-spawn.sh" boundary-mate "$LAB/mate" --secondmate --harness droid > "$LAB/secondmate.log" 2>&1 || rc=$?
cat "$LAB/secondmate.log"
[ "$rc" -ne 0 ]
grep -q 'verified crewmate/scout adapter only' "$LAB/secondmate.log"
[ ! -e "$FM_HOME/state/mate.droid-settings.json" ]
printf 'SECOND_MATE_BOUNDARY refused-before-launch=true exit=%s\n' "$rc"
printf 'window=firstmate:fm-boundary-mate\nworktree=%s\nproject=%s\nkind=secondmate\nharness=claude\n' "$LAB/mate" "$LAB/mate" > "$FM_HOME/state/boundary-mate.meta"
cp "$FM_HOME/state/boundary-mate.meta" "$LAB/prior.meta"
rc=0
"$ROOT/bin/fm-control.sh" boundary-mate relaunch --harness droid > "$LAB/relaunch.log" 2>&1 || rc=$?
cat "$LAB/relaunch.log"
[ "$rc" -ne 0 ]
grep -q 'not verified to run a secondmate task' "$LAB/relaunch.log"
cmp "$LAB/prior.meta" "$FM_HOME/state/boundary-mate.meta"
[ ! -e "$FM_HOME/state/boundary-mate.droid-settings.json" ]
printf 'SECOND_MATE_RELAUNCH refused-before-stop=true metadata=unchanged exit=%s\n' "$rc"
