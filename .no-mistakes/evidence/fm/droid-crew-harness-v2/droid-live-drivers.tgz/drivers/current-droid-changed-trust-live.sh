#!/usr/bin/env bash
set -euo pipefail
ROOT=$PWD
LAB=$(mktemp -d "$TMPDIR/droid-changed-trust.XXXXXX")
trap 'chmod -R u+w "$LAB"; rm -rf "$LAB"' EXIT
export HOME="$LAB/user"
mkdir -p "$HOME/.factory" "$LAB/state"
git init -q -b main "$LAB/project"
git -C "$LAB/project" -c user.name=guard -c user.email=guard@local commit -q --allow-empty -m init
git -C "$LAB/project" worktree add -q --detach "$LAB/task"
printf '%s\n' '{"otherSetting":"preserve","trustedFolders":{"/unrelated":{"trustedAt":"existing"}}}' > "$HOME/.factory/settings.json"
"$ROOT/bin/fm-droid-trust.sh" --receipt "$LAB/state/task.droid-trust" "$LAB/task" "$LAB/project"
jq --arg path "$LAB/task" '.trustedFolders[$path].trustedAt="changed-by-user"' "$HOME/.factory/settings.json" > "$LAB/store.new"
mv "$LAB/store.new" "$HOME/.factory/settings.json"
cp "$HOME/.factory/settings.json" "$LAB/before"
"$ROOT/bin/fm-droid-trust.sh" --rollback "$LAB/state/task.droid-trust"
cmp "$HOME/.factory/settings.json" "$LAB/before"
[ ! -e "$LAB/state/task.droid-trust" ]
printf 'CHANGED_GRANT_ROLLBACK retained-user-change=true receipt-retired=true\n'
cat "$HOME/.factory/settings.json"
