from pathlib import Path
import html,re
E=Path('/Users/dela/.no-mistakes/evidence/01M4H9BQAD97ANPCJV94NT4EX4')
parts=[]
def render(raw):
    state={}
    out=[]
    for token in re.split(r'(\x1b\[[0-9;]*m)',raw.rstrip()):
        if token.startswith('\x1b['):
            seq=[int(x or 0) for x in token[2:-1].split(';')]
            i=0
            while i<len(seq):
                n=seq[i]
                if n==0: state={}
                elif n==1: state['font-weight']='bold'
                elif n==2: state['opacity']='0.65'
                elif n==22:
                    state.pop('font-weight',None); state.pop('opacity',None)
                elif n==39: state.pop('color',None)
                elif n==49: state.pop('background-color',None)
                elif n in (38,48) and i+4<len(seq) and seq[i+1]==2:
                    state['color' if n==38 else 'background-color']='rgb(%d,%d,%d)'%tuple(seq[i+2:i+5]); i+=4
                elif n==7: state['outline']='1px solid #dcdcdc'
                i+=1
        else:
            css=';'.join(f'{k}:{v}' for k,v in state.items())
            out.append(f'<span style="{css}">{html.escape(token)}</span>')
    return ''.join(out)
captures=[('droid-native-screen.ansi','Credentialed Droid busy turn'),('droid-native-completed.ansi','Native model completed report and Stop hook'),('droid-native-draft.ansi','Unsent draft preserved after public exit refusal'),('droid-native-settings.ansi','Native runtime model and dynamic effort'),('droid-scout-screen.ansi','Scout launched through fm-spawn')]
for filename,title in captures:
    p=E/filename
    if p.exists() and p.stat().st_size:
        parts.append(f'<section><h2>{title}</h2><p>Real tmux ANSI capture · {filename}</p><pre>{render(p.read_text())}</pre></section>')
css='''body{margin:0;padding:32px;background:#181818;color:#dedad8;font:15px system-ui}h1{font-size:24px}h2{font-size:18px;color:#eb9234;margin:0}p{color:#a8a29d;font-size:13px}section{margin:28px 0;border:1px solid #45413e;border-radius:10px;padding:20px;min-width:0}pre{background:#121212;border-radius:6px;padding:16px;overflow:auto;font:12px/1.55 Menlo,monospace;white-space:pre}'''
(E/'droid-terminal-evidence.html').write_text('<!doctype html><html><head><meta charset="utf-8"><title>Droid current-head live evidence</title><style>'+css+'</style></head><body><h1>Droid 0.237.0 · live terminal evidence</h1><p>Captured against b8d5646cb99a3404a4abacc3c8e7be27cd1bd957 in isolated disposable homes. Terminal colors and text come from the running CLI.</p>'+''.join(parts)+'</body></html>')
