#!/usr/bin/env bash
set -euo pipefail
ROOT=$PWD
LAB=$(mktemp -d "$TMPDIR/fm-lab-background.XXXXXX")
SOCKET="fm-lab-background-$$"
DROID_BIN=$(command -v droid)
cleanup() { [ ! -f "$LAB/background.pid" ] || kill -KILL "$(cat "$LAB/background.pid")" 2>/dev/null || true; tmux -L "$SOCKET" kill-server >/dev/null 2>&1 || true; sleep 1; chmod -R u+w "$LAB"; rm -rf "$LAB"; }
trap cleanup EXIT
unset FM_ROOT_OVERRIDE FM_STATE_OVERRIDE FM_DATA_OVERRIDE FM_CONFIG_OVERRIDE FM_PROJECTS_OVERRIDE FM_GATE_REFUSE_BYPASS TASKS_AXI_FILE TASKS_AXI_BACKEND TMUX_TMPDIR
export HOME="$LAB/user" FM_HOME="$LAB/fleet"
mkdir -p "$HOME/.factory" "$LAB/shim"
printf '{}\n' > "$LAB/runtime-settings.json"
"$ROOT/bin/fm-lab-home.sh" create "$FM_HOME"
printf 'tmux\n' > "$FM_HOME/config/backend"
printf 'manual\n' > "$FM_HOME/config/backlog-backend"
git init -q -b main "$LAB/project"
git -C "$LAB/project" -c user.name=guard -c user.email=guard@local commit -q --allow-empty -m init
cat > "$LAB/foreground.sh" <<'BG'
#!/usr/bin/env bash
set -m
"$DROID_BIN" --settings "$LAB/runtime-settings.json" </dev/tty >/dev/tty 2>&1 &
printf '%s\n' "$!" > "$LAB/background.pid"
cat "$EVIDENCE/droid-native-completed.ansi"
printf '\033[43;1H'
while IFS= read -r text; do printf '%s\n' "$text" >> "$LAB/control-input"; done
BG
export LAB DROID_BIN EVIDENCE
# Explicit grid before the real vendor can inspect it.
tmux -L "$SOCKET" -f /dev/null new-session -d -s firstmate -n fm-background -c "$LAB/project" -x 140 -y 45 "bash --noprofile --norc '$LAB/foreground.sh'"
export TMUX
TMUX=$(tmux -L "$SOCKET" display-message -p -t firstmate '#{socket_path},#{pid},0')
cat > "$LAB/shim/tmux" <<WRAP
#!/usr/bin/env bash
exec "$(command -v tmux)" -L "$SOCKET" "\$@"
WRAP
chmod +x "$LAB/shim/tmux"
. "$ROOT/bin/fm-tmux-lib.sh"
TARGET=firstmate:fm-background
tty=$(tmux -L "$SOCKET" display-message -p -t "$TARGET" '#{pane_tty}')
for ((i=0;i<100;i++)); do
  ps -t "${tty#/dev/}" -o pid=,pgid=,tpgid=,comm= > "$LAB/processes"
  awk '$2 != $3 && $4 ~ /(^|\/)droid$/ {found=1} END {exit !found}' "$LAB/processes" && break
  sleep 0.1
 done
cat "$LAB/processes"
awk '$2 != $3 && $4 ~ /(^|\/)droid$/ {found=1} END {exit !found}' "$LAB/processes"
if PATH="$LAB/shim:$PATH" fm_tmux_pane_is_droid "$TARGET"; then echo 'background Droid claimed foreground'; exit 1; fi
verdict=$(PATH="$LAB/shim:$PATH" fm_tmux_composer_state "$TARGET")
[ "$verdict" = unknown ]
printf 'BACKGROUND_COMPOSER verdict=%s exact-vendor-background=true\n' "$verdict"
printf 'window=%s\nworktree=%s\nproject=%s\nkind=scout\nharness=droid\n' "$TARGET" "$LAB/project" "$LAB/project" > "$FM_HOME/state/background.meta"
rc=0
"$ROOT/bin/fm-control.sh" background exit || rc=$?
[ ! -s "$LAB/control-input" ]
printf 'BACKGROUND_CONTROL exit=%s no-control-input=true\n' "$rc"
