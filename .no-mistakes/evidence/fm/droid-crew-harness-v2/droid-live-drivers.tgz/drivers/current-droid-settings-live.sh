#!/usr/bin/env bash
set -euo pipefail
ROOT=$PWD
REAL_USER_HOME=$HOME
REAL_TASKS=$(command -v tasks-axi)
export FM_REAL_TASKS="$REAL_TASKS"
LAB=$(mktemp -d "$TMPDIR/droid's-public-settings.XXXXXX")
SOCKET="fm-droid-settings-$$"
cleanup() { /opt/homebrew/bin/tmux -L "$SOCKET" kill-server >/dev/null 2>&1 || true; sleep 1; chmod -R u+w "$LAB"; rm -rf "$LAB"; }
trap cleanup EXIT
unset FM_ROOT_OVERRIDE FM_STATE_OVERRIDE FM_DATA_OVERRIDE FM_CONFIG_OVERRIDE FM_PROJECTS_OVERRIDE FM_GATE_REFUSE_BYPASS TASKS_AXI_FILE TASKS_AXI_BACKEND TMUX_TMPDIR
mkdir -p "$LAB/user/.factory" "$LAB/faultbin"
for name in settings.json config.json auth.encrypted auth.v2.file auth.v2.key auth.v2.loginkeychain; do
  [ ! -f "$REAL_USER_HOME/.factory/$name" ] || cp "$REAL_USER_HOME/.factory/$name" "$LAB/user/.factory/$name"
done
jq 'del(.hooks,.trustedFolders,.enabledPlugins)' "$LAB/user/.factory/settings.json" > "$LAB/user/.factory/clean"
mv "$LAB/user/.factory/clean" "$LAB/user/.factory/settings.json"
export HOME="$LAB/user" FM_HOME="$LAB/fleet" TREEHOUSE_ROOT="$LAB/pool" DISABLE_AUTOUPDATER=1
bin/fm-lab-home.sh create "$FM_HOME"
cp .tasks.toml "$FM_HOME/.tasks.toml"
printf '# Backlog\n\n## In flight\n\n## Queued\n\n## Done\n' > "$FM_HOME/data/backlog.md"
printf 'tmux\n' > "$FM_HOME/config/backend"
# Local-only project data, with a disposable origin, never a public remote.
git init -q -b main "$LAB/project"
git -C "$LAB/project" -c user.name=guard -c user.email=guard@local commit -q --allow-empty -m init
git clone -q --bare "$LAB/project" "$LAB/origin.git"
git -C "$LAB/project" remote add origin "$LAB/origin.git"
/opt/homebrew/bin/tmux -L "$SOCKET" new-session -d -s firstmate -x 140 -y 45 -c "$LAB/project" 'bash --noprofile --norc'
export TMUX SHELL
TMUX=$(/opt/homebrew/bin/tmux -L "$SOCKET" display-message -p -t firstmate '#{socket_path},#{pid},0')
SHELL=$(command -v bash)
/opt/homebrew/bin/tmux -L "$SOCKET" set-option -g default-shell "$SHELL"
seed_task() {
  local id=$1
  mkdir -p "$FM_HOME/data/$id"
  printf '# Task\n## Captain'\''s intent\nThis is a credentialed launch verification only. Calculate 12345 + 67890. Use Execute to write only the sum to %s/data/%s/report.md and reply with it. Do not change project files, start validation, or do other work.\n\n## Firstmate spec\nVerify launch only.\n\n# Definition of done\nDelivery contract: mode=no-mistakes\n' "$FM_HOME" "$id" > "$FM_HOME/data/$id/brief.md"
  "$REAL_TASKS" add "$id" 'Disposable credentialed launch verification' --kind ship --file "$FM_HOME/data/backlog.md" >/dev/null
}
cat > "$LAB/faultbin/tmux" <<'WRAP'
#!/usr/bin/env bash
if [ "${FM_FAIL_LAUNCH:-0}" = 1 ]; then
  case "$*" in *send-keys*GOTMPDIR=*) touch "$FM_FAIL_MARKER"; printf 'Injected delivery failure before launch acceptance\n' >&2; exit 1 ;; esac
fi
exec /opt/homebrew/bin/tmux "$@"
WRAP
cat > "$LAB/faultbin/tasks-axi" <<'WRAP'
#!/usr/bin/env bash
if [ "${1:-}" = start ] && [ "${FM_INTERRUPT_LAUNCH:-0}" = 1 ] && [ ! -e "$FM_INTERRUPT_MARKER" ]; then
  "$FM_REAL_TASKS" "$@" || exit $?
  touch "$FM_INTERRUPT_MARKER"
  kill -TERM "$(cat "$FM_INTERRUPT_PIDFILE")"
  kill -TERM "$$"
fi
exec "$FM_REAL_TASKS" "$@"
WRAP
chmod +x "$LAB/faultbin/"*
seed_task failed-launch
rc=0
PATH="$LAB/faultbin:$PATH" FM_FAIL_LAUNCH=1 FM_FAIL_MARKER="$LAB/delivery-failed" bin/fm-spawn.sh failed-launch "$LAB/project" --harness droid --effort dynamic --mode no-mistakes --yolo off || rc=$?
[ "$rc" -ne 0 ]
[ -e "$LAB/delivery-failed" ]
[ ! -e "$FM_HOME/state/failed-launch.meta" ]
[ ! -e "$FM_HOME/state/failed-launch.droid-settings.json" ]
[ ! -e "$FM_HOME/state/failed-launch.droid-trust" ]
jq -e '(.trustedFolders // {}) | length == 0' "$HOME/.factory/settings.json"
printf 'FRESH_FAILURE_STATE metadata=absent settings=absent receipt=absent newly-acquired-trust=absent exit=%s\n' "$rc"
seed_task preserved-launch
PATH="$LAB/faultbin:$PATH" FM_REAL_TASKS="$REAL_TASKS" FM_INTERRUPT_LAUNCH=1 FM_INTERRUPT_MARKER="$LAB/interrupted" FM_INTERRUPT_PIDFILE="$LAB/spawn.pid" \
  bin/fm-spawn.sh preserved-launch "$LAB/project" --harness droid --model custom:GPT-5.6-Sol-0 --effort dynamic --mode no-mistakes --yolo off &
spawn_pid=$!
printf '%s\n' "$spawn_pid" > "$LAB/spawn.pid"
rc=0
wait "$spawn_pid" || rc=$?
[ "$rc" -ne 0 ]
[ -f "$FM_HOME/state/preserved-launch.meta" ]
[ -f "$FM_HOME/state/preserved-launch.droid-trust" ]
jq -e '.sessionDefaultSettings.model == "custom:GPT-5.6-Sol-0" and .sessionDefaultSettings.reasoningEffort == "dynamic"' "$FM_HOME/state/preserved-launch.droid-settings.json"
"$REAL_TASKS" show preserved-launch --file "$FM_HOME/data/backlog.md"
printf 'PRESERVED_RUNTIME_SETTINGS\n'; cat "$FM_HOME/state/preserved-launch.droid-settings.json"
for ((i=0;i<180;i++)); do
  [ ! -f "$FM_HOME/state/preserved-launch.turn-ended" ] || break
  sleep 1
done
[ -f "$FM_HOME/state/preserved-launch.turn-ended" ]
[ "$(tr -d '[:space:]' < "$FM_HOME/data/preserved-launch/report.md")" = 80235 ]
/opt/homebrew/bin/tmux -L "$SOCKET" capture-pane -p -t firstmate:fm-preserved-launch -S -50
printf 'PRESERVED_WORKER_STATE metadata=present settings=present receipt=present Stop=observed report=80235 spawn_exit=%s\n' "$rc"
